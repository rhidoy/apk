package com.ercan_isik.depremtoplanmaalani;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.ercan_isik.depremtoplanmaalani.database.DatabaseHelper;
import com.ercan_isik.depremtoplanmaalani.entity.LocationPojo;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;

import java.lang.ref.WeakReference;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    public static final String TAG = "activity";


    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;

    /**
     * Provides the entry point to the Fused LocationPojo Provider API.
     */
    private FusedLocationProviderClient mFusedLocationClient;

    private GoogleMap mMap;

    private double distance = 0.25;
    private LatLng latLng;
    private Marker marker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppTheme);
        setContentView(R.layout.activity_maps);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        mFusedLocationClient = LocationServices
                .getFusedLocationProviderClient(this);
    }

    @Override
    public void onStart() {
        super.onStart();

        if (!checkPermissions()) {
            requestPermissions();
        } else {
            getLastLocation();
        }
    }

    /**
     * Provides a simple way of getting a device's location and is well suited for
     * applications that do not require a fine-grained location and that do not need location
     * updates. Gets the best and most recent location currently available, which may be null
     * in rare cases when a location is not available.
     * <p>
     * Note: this method should be called after location permission has been granted.
     */
    @SuppressWarnings("MissingPermission")
    private void getLastLocation() {
        mFusedLocationClient.getLastLocation()
                .addOnCompleteListener(this,
                        task -> {
                            if (task.isSuccessful()
                                    && task.getResult() != null) {
                                Location result = task.getResult();

                                latLng = new LatLng(result.getLatitude(),
                                        result.getLongitude());

//                                latLng = new LatLng(41.087772,
//                                        29.042690);
                                distance = distance - 0.25;
                                new InitData(MapsActivity.this, 0.25f).execute();

                            } else {
                                showSnackbar(getString(R.
                                        string.no_location_detected));
                            }
                        });
    }

    /**
     * Shows a {@link Snackbar} using {@code text}.
     *
     * @param text The Snackbar text.
     */
    private void showSnackbar(final String text) {
        View container = findViewById(R.id.main_activity_container);
        if (container != null) {
            Snackbar.make(container, text, Snackbar.LENGTH_LONG).show();
        }
    }

    /**
     * Shows a {@link Snackbar}.
     *
     * @param mainTextStringId The id for the string resource for the Snackbar text.
     * @param actionStringId   The text of the action item.
     * @param listener         The listener associated with the Snackbar action.
     */
    private void showSnackbar(final int mainTextStringId, final int actionStringId,
                              View.OnClickListener listener) {
        Snackbar.make(findViewById(android.R.id.content),
                getString(mainTextStringId),
                Snackbar.LENGTH_INDEFINITE)
                .setAction(getString(actionStringId), listener).show();
    }

    /**
     * Return the current state of the permissions needed.
     */
    private boolean checkPermissions() {
        int permissionState = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        return permissionState == PackageManager.PERMISSION_GRANTED;
    }

    private void startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                REQUEST_PERMISSIONS_REQUEST_CODE);
    }

    private void requestPermissions() {
        boolean shouldProvideRationale =
                ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_FINE_LOCATION);

        // Provide an additional rationale to the user. This would happen if the user denied the
        // request previously, but didn't check the "Don't ask again" checkbox.
        if (shouldProvideRationale) {
            Log.e(TAG, "Displaying permission rationale to provide additional context.");

            showSnackbar(R.string.permission_rationale, android.R.string.ok,
                    view -> {
                        // Request permission
                        startLocationPermissionRequest();
                    });

        } else {
            Log.e(TAG, "Requesting permission");
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the user denied the permission
            // previously and checked "Never ask again".
            startLocationPermissionRequest();
        }
    }

    /**
     * Callback received when a permissions request has been completed.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.e(TAG, "onRequestPermissionResult");
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length <= 0) {
                // If user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                Log.e(TAG, "User interaction was cancelled.");
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted.
                getLastLocation();
            } else {
                // Permission denied.

                // Notify the user via a SnackBar that they have rejected a core permission for the
                // app, which makes the Activity useless. In a real app, core permissions would
                // typically be best requested during a welcome-screen flow.

                // Additionally, it is important to remember that a permission might have been
                // rejected without asking the user for permission (device policy or "Never ask
                // again" prompts). Therefore, a user interface affordance is typically implemented
                // when permissions are denied. Otherwise, your app could appear unresponsive to
                // touches or interactions which have required permissions.
                showSnackbar(R.string.permission_denied_explanation, R.string.settings,
                        view -> {
                            // Build intent that displays the App settings screen.
                            Intent intent = new Intent();
                            intent.setAction(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package",
                                    BuildConfig.APPLICATION_ID, null);
                            intent.setData(uri);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        });
            }
        }
    }


    public void nextLocation(View view) {
        if (latLng != null)
            new InitData(this, 0.25f).execute();
        findViewById(R.id.btn_previous_location)
                .setVisibility(View.VISIBLE);

    }

    public void previousLocation(View view) {
        if (latLng != null)
            new InitData(this, -0.25f).execute();
        if (distance<=0.25)
        findViewById(R.id.btn_previous_location)
                .setVisibility(View.GONE);
    }


    @SuppressLint("StaticFieldLeak")
    private class InitData extends AsyncTask<Void, Void, LocationPojo> {
        WeakReference<Context> context;
        float value;


        InitData(Context context, float value) {
            this.context = new WeakReference<>(context);
            this.value = value;
        }


        @Override
        protected LocationPojo doInBackground(Void... voids) {
            Context context1 = context.get();
            LocationPojo locationPojo = null;
            if (context1 != null) {
                DatabaseHelper databaseHelper = new DatabaseHelper(context1);
                databaseHelper.createDataBase();
                do {
                    distance = distance + value;
                    String query = databaseHelper
                            .generateQuery(latLng.latitude,
                                    latLng.longitude,
                                    distance);
                    locationPojo = databaseHelper
                            .getSafeCampByUserLatandLng(query);
                } while (locationPojo == null && distance < 1000);
            }
            return locationPojo;
        }

        @Override
        protected void onPostExecute(LocationPojo locationPojo) {
            super.onPostExecute(locationPojo);
            if (locationPojo == null) {
                Toast.makeText(MapsActivity.this,
                        "No Location Found.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (marker != null)
                marker.remove();
            LatLng latLng = new LatLng(locationPojo.getLat(),
                    locationPojo.getLang());
            addMarker(new MarkerOptions()
                            .position(latLng)
                            .title(locationPojo.getAddress()),
                    latLng);
        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        mMap.getFocusedBuilding();
    }

    private void addMarker(MarkerOptions markerOptions, LatLng latLng) {
        if (mMap != null) {
            marker = mMap.addMarker(markerOptions);
            marker.showInfoWindow();
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory
                    .newLatLngZoom(latLng, 12.0f));
        }
    }
}

