package com.ercan_isik.depremtoplanmaalani.entity;

/**
 * Created by Rhidoy on 10/20/19.
 */
public class LocationPojo {
    private int id;
    private String name;
    private String address;
    private double lat;
    private double lang;

    public LocationPojo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLang() {
        return lang;
    }

    public void setLang(double lang) {
        this.lang = lang;
    }

    @Override
    public String toString() {
        return "LocationPojo{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", lat=" + lat +
                ", lang=" + lang +
                '}';
    }
}
